# HX//RACE — Interactive Heat Exchanger Design & Rating Simulator

HX//RACE is a full-stack engineering simulator scaffold for shell-and-tube heat exchangers with an F1-inspired telemetry interface, live TEMA configuration visualization, screening thermal/hydraulic calculations, bounded optimisation, and technical-pack exports.

## What works in this build

- FastAPI engineering API
- React + TypeScript cockpit
- Live BEM/AES/BEU/etc. TEMA code selection and geometry-aware head drawing
- Baffle count visualization and animated shell/tube flow paths
- Design and rating modes
- Hot/cold stream inputs
- CoolProp pure-fluid property calls when available, including IF97 water path
- Energy balance, LMTD, overall U, required/installed area
- Tube-side Reynolds/Prandtl/Nusselt/h/pressure-drop screening
- Shell-side Reynolds/Prandtl/Nusselt/h/pressure-drop screening
- Discrete geometry optimiser with pressure-drop and area constraints
- Downloadable engineering-sheet PDF, component-register CSV and simulation JSON

## Engineering boundary — important

This is **not** a TEMA-certified design program and does not issue TEMA certification or ASME code stamps. The current solver intentionally identifies itself as a screening engine. The shell-side method is a Kern-style screening model and the current F factor is provisional. The next production-grade engine should implement validated Bell-Delaware geometry corrections, robust multiphase/mixture thermodynamics, vibration checks, mechanical/code calculations, and authoritative design review.

TEMA 2026 is subscription material; do not copy protected standard text into this repository. Use permitted nomenclature and user-owned/licensed data only.

## Run locally

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API docs: `http://localhost:8000/docs`

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## Repository architecture

```text
backend/
  app/
    main.py                 FastAPI endpoints
    models.py               typed API contract
    engine/
      tema.py               TEMA nomenclature/config model
      properties.py         property-provider interface / CoolProp
      shell_tube.py         screening thermal-hydraulic engine
      optimizer.py          bounded design search
      exporters.py          PDF/CSV technical-pack generation
  tests/
frontend/
  src/
    App.tsx                 cockpit
    components/
      TemaVisualizer.tsx    longitudinal TEMA view + flow animation
    lib/api.ts              API client
    styles.css              F1-inspired interface
```

## Production roadmap already supported by this architecture

1. Bell-Delaware shell-side implementation and geometry correction factors.
2. Temperature-segmented exchanger model rather than mean-property-only calculation.
3. Real multicomponent thermodynamic layer for Peng-Robinson/SRK/NRTL/UNIQUAC and phase-equilibrium handling.
4. Condenser, kettle, thermosiphon and vaporizer models.
5. Plate-and-frame, double-pipe and air-cooled exchanger plugins.
6. Cross-sectional tube-bundle visualizer and pass-partition geometry.
7. Tube vibration, fouling, erosion, nozzle ΔP and mechanical design checks.
8. Formal project database, versioned cases and compare-runs telemetry.
9. Full SI/US-customary engineering-sheet templates and revision control.
10. Multi-objective optimizer (area/cost/ΔP/duty/manufacturability).

## Naming and compliance

Use phrases such as **"TEMA-aligned"**, **"TEMA configuration"**, or **"designed/checked against licensed TEMA criteria"** when justified. Do not label a software-generated document **"TEMA Certified"** unless the certification is actually issued through an authorized process.
