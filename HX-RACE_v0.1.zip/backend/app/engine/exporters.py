from __future__ import annotations

from io import BytesIO, StringIO
import csv
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.models import SimulationRequest, SimulationResult


def component_rows(req: SimulationRequest) -> list[list[str]]:
    g = req.geometry
    return [
        ["Shell", f"{req.tema.shell} shell, ID {g.shell_id_m:.3f} m", "To be selected", "Pressure boundary"],
        ["Front head", req.tema.front, "To be selected", "TEMA front head"],
        ["Rear head", req.tema.rear, "To be selected", "TEMA rear head"],
        ["Tube bundle", f"{g.tube_count} tubes × {g.tube_od_mm:.2f} mm OD × {g.tube_length_m:.2f} m", "To be selected", "Thermal surface"],
        ["Tube passes", str(g.tube_passes), "—", "Flow arrangement"],
        ["Cross baffles", f"{g.baffle_count} baffles, {g.baffle_cut_pct:.1f}% cut", "To be selected", "Shell-side flow control"],
        ["Tube layout", g.tube_layout, "—", f"Pitch {g.tube_pitch_mm:.2f} mm"],
        ["Tubesheets", "Geometry-dependent", "To be selected", "Mechanical design pending"],
        ["Tie rods / spacers", "Geometry-dependent", "To be selected", "Mechanical design pending"],
        ["Nozzles", "Shell + tube side inlet/outlet", "To be selected", "Nozzle sizing pending"],
    ]


def component_csv(req: SimulationRequest) -> str:
    sio = StringIO()
    writer = csv.writer(sio)
    writer.writerow(["Component", "Specification", "Material", "Note"])
    writer.writerows(component_rows(req))
    return sio.getvalue()


def engineering_pdf(req: SimulationRequest, res: SimulationResult) -> bytes:
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=15*mm, leftMargin=15*mm, topMargin=14*mm, bottomMargin=14*mm)
    styles = getSampleStyleSheet()
    story = [
        Paragraph("HX//RACE — Heat Exchanger Engineering Sheet", styles["Title"]),
        Paragraph("TEMA-aligned simulation output — NOT TEMA certification, ASME stamping, or fabrication approval.", styles["BodyText"]),
        Spacer(1, 6*mm),
    ]
    header = [
        ["Item", "HX-701", "TEMA configuration", res.tema_code],
        ["Mode", req.mode.value, "Thermodynamic selection", req.thermo_package.value],
        ["Hot fluid", req.hot_stream.fluid, "Cold fluid", req.cold_stream.fluid],
    ]
    table = Table(header, colWidths=[30*mm, 55*mm, 40*mm, 55*mm])
    table.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.5,colors.grey),("BACKGROUND",(0,0),(0,-1),colors.whitesmoke),("BACKGROUND",(2,0),(2,-1),colors.whitesmoke),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story += [table, Spacer(1,5*mm), Paragraph("Thermal / Hydraulic Summary", styles["Heading2"])]
    summary = [
        ["Duty", f"{res.duty_kw:.1f} kW", "Required area", f"{res.required_area_m2:.2f} m²"],
        ["Installed area", f"{res.installed_area_m2:.2f} m²", "Area margin", f"{res.area_margin_pct:.1f}%"],
        ["Overall U", f"{res.overall_u_w_m2k:.1f} W/m²K", "LMTD × F", f"{res.effective_delta_t_c:.2f} °C"],
        ["Tube ΔP", f"{res.tube_dp_kpa:.2f} kPa", "Shell ΔP", f"{res.shell_dp_kpa:.2f} kPa"],
        ["Tube velocity", f"{res.tube_velocity_m_s:.3f} m/s", "Shell velocity", f"{res.shell_velocity_m_s:.3f} m/s"],
        ["Hot outlet", f"{res.hot_outlet_c:.2f} °C", "Cold outlet", f"{res.cold_outlet_c:.2f} °C"],
    ]
    s_table = Table(summary, colWidths=[32*mm, 48*mm, 32*mm, 48*mm])
    s_table.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.4,colors.grey),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story += [s_table, Spacer(1,5*mm), Paragraph("Component Register", styles["Heading2"])]
    rows = [["Component","Specification","Material","Note"], *component_rows(req)]
    c_table = Table(rows, colWidths=[30*mm, 65*mm, 35*mm, 45*mm], repeatRows=1)
    c_table.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.35,colors.grey),("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("FONTSIZE",(0,0),(-1,-1),8),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story += [c_table, Spacer(1,5*mm), Paragraph("Methodology / Limitations", styles["Heading2"])]
    for line in res.methodology:
        story.append(Paragraph(f"• {line}", styles["BodyText"]))
    if res.warnings:
        story += [Spacer(1,3*mm), Paragraph("Warnings", styles["Heading3"])]
        for line in res.warnings:
            story.append(Paragraph(f"• {line}", styles["BodyText"]))
    doc.build(story)
    return buf.getvalue()
