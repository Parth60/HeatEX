from __future__ import annotations

from io import BytesIO

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from app.engine.exporters import component_csv, engineering_pdf
from app.engine.optimizer import optimise
from app.engine.shell_tube import simulate
from app.engine.tema import FRONT_HEADS, REAR_HEADS, SHELL_TYPES
from app.models import SimulationRequest

app = FastAPI(title="HX//RACE Engineering API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "HX//RACE"}


@app.get("/api/tema/options")
def tema_options():
    return {"front_heads": FRONT_HEADS, "shell_types": SHELL_TYPES, "rear_heads": REAR_HEADS}


@app.post("/api/simulate")
def run_simulation(req: SimulationRequest):
    try:
        return simulate(req)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/optimise")
def run_optimiser(req: SimulationRequest, objective: str = Query("balanced")):
    try:
        return optimise(req, objective)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/export/component-register.csv")
def export_component_register(req: SimulationRequest):
    data = component_csv(req)
    return Response(content=data, media_type="text/csv", headers={"Content-Disposition": "attachment; filename=HX_component_register.csv"})


@app.post("/api/export/engineering-sheet.pdf")
def export_engineering_sheet(req: SimulationRequest):
    try:
        res = simulate(req)
        data = engineering_pdf(req, res)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return Response(content=data, media_type="application/pdf", headers={"Content-Disposition": "attachment; filename=HX_engineering_sheet.pdf"})


@app.post("/api/export/simulation.json")
def export_simulation_json(req: SimulationRequest):
    try:
        res = simulate(req)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return JSONResponse({"request": req.model_dump(mode="json"), "result": res.model_dump(mode="json")}, headers={"Content-Disposition": "attachment; filename=HX_simulation.json"})


FRONTEND_STATIC = Path(__file__).resolve().parents[2] / "frontend-static"
if FRONTEND_STATIC.exists():
    app.mount("/", StaticFiles(directory=FRONTEND_STATIC, html=True), name="frontend")
