export const API = import.meta.env.VITE_API_URL ?? 'http://localhost:8000'

export type SimRequest = {
  mode: 'design' | 'rating'
  thermo_package: 'CoolProp' | 'Ideal' | 'Peng-Robinson' | 'SRK' | 'NRTL' | 'UNIQUAC' | 'IAPWS'
  flow_arrangement: 'counter-current' | 'co-current'
  thermal_spec: 'hot-outlet' | 'cold-outlet' | 'duty'
  thermal_target: number
  hot_stream: { fluid: string; mass_flow_kg_s: number; inlet_temp_c: number; pressure_bar: number }
  cold_stream: { fluid: string; mass_flow_kg_s: number; inlet_temp_c: number; pressure_bar: number }
  geometry: {
    shell_id_m: number; tube_od_mm: number; tube_id_mm: number; tube_length_m: number; tube_count: number;
    tube_passes: number; tube_pitch_mm: number; tube_layout: string; baffle_count: number; baffle_cut_pct: number;
    tube_wall_k_w_mk: number; tube_fouling_m2k_w: number; shell_fouling_m2k_w: number
  }
  tema: { front: string; shell: string; rear: string }
  tube_dp_limit_kpa: number
  shell_dp_limit_kpa: number
}

export async function simulate(body: SimRequest) {
  const response = await fetch(`${API}/api/simulate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
  if (!response.ok) throw new Error((await response.json()).detail ?? 'Simulation failed')
  return response.json()
}

export async function optimise(body: SimRequest, objective = 'balanced') {
  const response = await fetch(`${API}/api/optimise?objective=${encodeURIComponent(objective)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
  if (!response.ok) throw new Error((await response.json()).detail ?? 'Optimisation failed')
  return response.json()
}

export async function downloadExport(body: SimRequest, path: string, filename: string) {
  const response = await fetch(`${API}${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
  if (!response.ok) throw new Error('Export failed')
  const blob = await response.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url)
}
