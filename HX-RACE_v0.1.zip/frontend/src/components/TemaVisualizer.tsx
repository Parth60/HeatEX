import { useMemo } from 'react'

type Props = { front: string; shell: string; rear: string; baffles: number; tubePasses: number; running: boolean }

export default function TemaVisualizer({ front, shell, rear, baffles, tubePasses, running }: Props) {
  const code = `${front}${shell}${rear}`
  const xs = useMemo(() => Array.from({ length: Math.min(baffles, 28) }, (_, i) => 155 + (500 * (i + 1)) / (Math.min(baffles, 28) + 1)), [baffles])
  const frontPath = front === 'D' ? 'M130 70 L85 70 L68 96 L68 194 L85 220 L130 220' : (front === 'A' || front === 'C' || front === 'N') ? 'M130 70 L86 70 Q65 145 86 220 L130 220' : 'M130 72 Q76 95 76 145 Q76 195 130 218'
  const rearPath = rear === 'U' ? 'M630 72 Q700 90 676 145 Q700 200 630 218' : ['P','S','T','W'].includes(rear) ? 'M630 70 L675 70 Q698 145 675 220 L630 220' : 'M630 72 Q684 95 684 145 Q684 195 630 218'
  return <div className="visualizer panel">
    <div className="visualizer-head"><div><span className="eyebrow">LIVE MACHINE VIEW</span><h2>{code} cutaway</h2></div><span className={`status ${running ? 'live' : ''}`}>{running ? 'LIVE FLOW' : 'STANDBY'}</span></div>
    <svg viewBox="0 0 760 285" role="img" aria-label={`${code} shell and tube heat exchanger schematic`}>
      <defs><marker id="hotArrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0 0L0 6L7 3Z" className="hotFill"/></marker><marker id="coldArrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0 0L0 6L7 3Z" className="coldFill"/></marker></defs>
      <rect x="130" y="55" width="500" height="180" rx="34" className="shellBody"/>
      <path d={frontPath} className="headPath"/><path d={rearPath} className="headPath"/>
      {[105,128,151,174].map(y => <line key={y} x1="126" y1={y} x2="634" y2={y} className="tubeLine"/>)}
      {xs.map((x,i)=><line key={i} x1={x} x2={x} y1={i%2 ? 112 : 72} y2={i%2 ? 220 : 177} className="baffle"/>)}
      <path d="M92 110H655" className={`flowPath hot ${running ? 'moving' : ''}`} markerEnd="url(#hotArrow)"/>
      <path d="M610 205C570 205 555 83 510 83S455 205 410 205S355 83 310 83S255 205 210 205S155 83 122 83" className={`flowPath cold ${running ? 'moving' : ''}`} markerEnd="url(#coldArrow)"/>
      <text x="380" y="30" textAnchor="middle" className="svgLabel">{code} // {baffles} BAFFLES // {tubePasses} TUBE PASSES</text>
      <text x="92" y="263" className="svgHot">HOT / TUBE</text><text x="560" y="263" className="svgCold">COLD / SHELL</text>
    </svg>
  </div>
}
