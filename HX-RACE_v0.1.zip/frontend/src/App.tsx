import { useEffect, useMemo, useState } from 'react'
import { Activity, Download, Gauge, Play, Square, Zap } from 'lucide-react'
import TemaVisualizer from './components/TemaVisualizer'
import { downloadExport, optimise, simulate, type SimRequest } from './lib/api'

const base: SimRequest = {
  mode: 'design', thermo_package: 'CoolProp', flow_arrangement: 'counter-current', thermal_spec: 'hot-outlet', thermal_target: 70,
  hot_stream: { fluid: 'Ethanol', mass_flow_kg_s: 12, inlet_temp_c: 140, pressure_bar: 4 },
  cold_stream: { fluid: 'Water', mass_flow_kg_s: 18, inlet_temp_c: 25, pressure_bar: 3 },
  geometry: { shell_id_m: .8, tube_od_mm: 19.05, tube_id_mm: 15.75, tube_length_m: 6, tube_count: 420, tube_passes: 2, tube_pitch_mm: 25, tube_layout: 'triangular-30', baffle_count: 12, baffle_cut_pct: 25, tube_wall_k_w_mk: 16, tube_fouling_m2k_w: .0002, shell_fouling_m2k_w: .0002 },
  tema: { front: 'B', shell: 'E', rear: 'M' }, tube_dp_limit_kpa: 70, shell_dp_limit_kpa: 50,
}

const f1 = (x:number|undefined, digits=1) => Number.isFinite(x) ? x!.toFixed(digits) : '—'

export default function App() {
  const [req,setReq]=useState<SimRequest>(base); const [res,setRes]=useState<any>(null); const [error,setError]=useState(''); const [running,setRunning]=useState(false); const [busy,setBusy]=useState(false)
  const temaCode = `${req.tema.front}${req.tema.shell}${req.tema.rear}`
  const patchGeometry=(key:string,value:number|string)=>setReq(r=>({...r,geometry:{...r.geometry,[key]:value}}))
  const run=async()=>{setBusy(true);setError('');try{setRes(await simulate(req))}catch(e:any){setError(e.message)}finally{setBusy(false)}}
  useEffect(()=>{const t=setTimeout(run,180);return()=>clearTimeout(t)},[req])
  const doOptimise=async()=>{setBusy(true);try{const out=await optimise(req,'balanced');if(out.found){setReq(out.request);setRes(out.result)}else setError(out.message)}catch(e:any){setError(e.message)}finally{setBusy(false)}}
  const score=Math.round(res?.screening_score ?? 0)
  return <main className="appShell">
    <header className="topbar"><div><span className="eyebrow">HX//RACE • THERMAL SYSTEMS LAB</span><h1>{temaCode} <span>/</span> HX-701</h1></div><div className="headerActions"><button className="btn primary" onClick={()=>setRunning(v=>!v)}>{running?<Square size={16}/>:<Play size={16}/>} {running?'BOX / STOP':'PUSH SIM'}</button><button className="btn" onClick={doOptimise}><Zap size={16}/> OPTIMISE</button></div></header>
    <div className="raceLine"/>
    <section className="kpis">
      <Kpi icon={<Activity/>} label="Heat duty" value={`${f1((res?.duty_kw ?? 0)/1000,2)} MW`} sub="LIVE ENERGY TRANSFER"/>
      <Kpi icon={<Gauge/>} label="Required area" value={`${f1(res?.required_area_m2)} m²`} sub={`INSTALLED ${f1(res?.installed_area_m2)} m²`}/>
      <Kpi icon={<Gauge/>} label="Tube ΔP" value={`${f1(res?.tube_dp_kpa)} kPa`} sub={`LIMIT ${req.tube_dp_limit_kpa} kPa`}/>
      <Kpi icon={<Zap/>} label="Design score" value={`${score}`} sub={score>90?'PURPLE SECTOR':score>75?'GREEN SECTOR':'SETUP REVIEW'}/>
    </section>

    <section className="workspace">
      <aside className="panel controls"><span className="eyebrow">CAR SETUP / PROCESS</span><h2>Simulation inputs</h2>
        <div className="segmented"><button className={req.mode==='design'?'active':''} onClick={()=>setReq(r=>({...r,mode:'design'}))}>DESIGN</button><button className={req.mode==='rating'?'active':''} onClick={()=>setReq(r=>({...r,mode:'rating'}))}>RATING</button></div>
        <Field label="Thermodynamic package"><select value={req.thermo_package} onChange={e=>setReq(r=>({...r,thermo_package:e.target.value as any}))}>{['CoolProp','Ideal','Peng-Robinson','SRK','NRTL','UNIQUAC','IAPWS'].map(x=><option key={x}>{x}</option>)}</select></Field>
        <Field label="Thermal target / hot outlet °C"><input type="number" value={req.thermal_target} onChange={e=>setReq(r=>({...r,thermal_target:+e.target.value}))}/></Field>
        <div className="miniGrid"><Field label="Hot fluid"><select value={req.hot_stream.fluid} onChange={e=>setReq(r=>({...r,hot_stream:{...r.hot_stream,fluid:e.target.value}}))}>{['Water','Ethanol','Butanol','Toluene'].map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Hot kg/s"><input type="number" value={req.hot_stream.mass_flow_kg_s} onChange={e=>setReq(r=>({...r,hot_stream:{...r.hot_stream,mass_flow_kg_s:+e.target.value}}))}/></Field><Field label="Hot inlet °C"><input type="number" value={req.hot_stream.inlet_temp_c} onChange={e=>setReq(r=>({...r,hot_stream:{...r.hot_stream,inlet_temp_c:+e.target.value}}))}/></Field><Field label="Cold fluid"><select value={req.cold_stream.fluid} onChange={e=>setReq(r=>({...r,cold_stream:{...r.cold_stream,fluid:e.target.value}}))}>{['Water','Ethanol','Butanol','Toluene'].map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Cold kg/s"><input type="number" value={req.cold_stream.mass_flow_kg_s} onChange={e=>setReq(r=>({...r,cold_stream:{...r.cold_stream,mass_flow_kg_s:+e.target.value}}))}/></Field><Field label="Cold inlet °C"><input type="number" value={req.cold_stream.inlet_temp_c} onChange={e=>setReq(r=>({...r,cold_stream:{...r.cold_stream,inlet_temp_c:+e.target.value}}))}/></Field></div>
        <span className="eyebrow sectionLabel">TEMA CONFIG</span><div className="temaSelects"><Field label="Front"><select value={req.tema.front} onChange={e=>setReq(r=>({...r,tema:{...r.tema,front:e.target.value}}))}>{['A','B','C','N','D'].map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Shell"><select value={req.tema.shell} onChange={e=>setReq(r=>({...r,tema:{...r.tema,shell:e.target.value}}))}>{['E','F','G','H','J','K','X'].map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Rear"><select value={req.tema.rear} onChange={e=>setReq(r=>({...r,tema:{...r.tema,rear:e.target.value}}))}>{['L','M','N','P','S','T','U','W'].map(x=><option key={x}>{x}</option>)}</select></Field></div>
      </aside>

      <div className="centerStack"><TemaVisualizer {...req.tema} baffles={req.geometry.baffle_count} tubePasses={req.geometry.tube_passes} running={running}/>
        <div className="panel geometry"><div className="panelTitle"><div><span className="eyebrow">AERO / GEOMETRY</span><h2>Machine setup</h2></div><span className="tag">LIVE LINKED</span></div><div className="geometryGrid">
          <Field label="Shell ID m"><input type="number" step=".01" value={req.geometry.shell_id_m} onChange={e=>patchGeometry('shell_id_m',+e.target.value)}/></Field><Field label="Tube OD mm"><select value={req.geometry.tube_od_mm} onChange={e=>patchGeometry('tube_od_mm',+e.target.value)}><option value={15.88}>15.88</option><option value={19.05}>19.05</option><option value={25.4}>25.40</option></select></Field><Field label="Tube count"><input type="number" value={req.geometry.tube_count} onChange={e=>patchGeometry('tube_count',+e.target.value)}/></Field><Field label="Tube passes"><select value={req.geometry.tube_passes} onChange={e=>patchGeometry('tube_passes',+e.target.value)}>{[1,2,4,6,8].map(x=><option key={x}>{x}</option>)}</select></Field><Field label={`Baffles ${req.geometry.baffle_count}`}><input type="range" min="2" max="30" value={req.geometry.baffle_count} onChange={e=>patchGeometry('baffle_count',+e.target.value)}/></Field><Field label="Baffle cut %"><input type="number" value={req.geometry.baffle_cut_pct} onChange={e=>patchGeometry('baffle_cut_pct',+e.target.value)}/></Field>
        </div></div>
      </div>

      <aside className="panel telemetry"><span className="eyebrow">PIT WALL / TELEMETRY</span><h2>Thermal-hydraulic</h2>{busy&&<div className="loading">RECALCULATING…</div>}{error&&<div className="error">{error}</div>}
        <Telemetry label="Overall U" value={`${f1(res?.overall_u_w_m2k,0)} W/m²K`}/><Telemetry label="LMTD × F" value={`${f1(res?.effective_delta_t_c)} °C`}/><Telemetry label="Hot outlet" value={`${f1(res?.hot_outlet_c)} °C`}/><Telemetry label="Cold outlet" value={`${f1(res?.cold_outlet_c)} °C`}/><Telemetry label="Tube velocity" value={`${f1(res?.tube_velocity_m_s,2)} m/s`}/><Telemetry label="Tube Reynolds" value={f1(res?.tube_reynolds,0)}/><Telemetry label="Shell velocity" value={`${f1(res?.shell_velocity_m_s,2)} m/s`}/><Telemetry label="Shell ΔP" value={`${f1(res?.shell_dp_kpa)} kPa`}/><Telemetry label="Area margin" value={`${f1(res?.area_margin_pct)} %`}/>
        <div className="warningBox">{res?.warnings?.length ? res.warnings.map((x:string,i:number)=><div key={i}>⚠ {x}</div>) : '✓ Screening checks clear'}</div>
        <span className="eyebrow sectionLabel">TECHNICAL PACK</span><button className="btn export" onClick={()=>downloadExport(req,'/api/export/engineering-sheet.pdf','HX_engineering_sheet.pdf')}><Download size={16}/> ENGINEERING SHEET PDF</button><button className="btn export" onClick={()=>downloadExport(req,'/api/export/component-register.csv','HX_component_register.csv')}><Download size={16}/> COMPONENT REGISTER CSV</button><button className="btn export" onClick={()=>downloadExport(req,'/api/export/simulation.json','HX_simulation.json')}><Download size={16}/> SIMULATION JSON</button><p className="legal">TEMA-aligned engineering output. Not TEMA certification, ASME stamping or fabrication approval.</p>
      </aside>
    </section>
  </main>
}

function Kpi({icon,label,value,sub}:{icon:any,label:string,value:string,sub:string}){return <div className="kpi"><span className="kpiIcon">{icon}</span><div><span>{label}</span><strong>{value}</strong><small>{sub}</small></div></div>}
function Field({label,children}:{label:string,children:any}){return <label className="field"><span>{label}</span>{children}</label>}
function Telemetry({label,value}:{label:string,value:string}){return <div className="telemetryRow"><span>{label}</span><strong>{value}</strong></div>}
