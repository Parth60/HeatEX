# HX//RACE Project Roadmap

## v0.1 — Foundation
- Shell-and-tube screening engine
- TEMA configuration model
- Design and rating modes
- Basic optimiser and exporters

## v0.2 — Streamlit Cockpit
- Streamlit engineering UI
- Live TEMA schematic
- Geometry controls
- Live thermal/hydraulic telemetry
- JSON technical-pack download

## v0.3 — Shell & Tube Pro
- Bell–Delaware shell-side model
- Segment-by-segment temperature/property calculation
- Tube-bundle cross-section
- Tube-pass partitions
- Nozzle pressure drop
- Baffle leakage/bypass visualisation

## v0.4 — Thermodynamics
- Pure-fluid property provider validation
- Peng–Robinson / SRK mixture layer
- NRTL / UNIQUAC activity-coefficient layer
- Phase detection
- Condensation / boiling duty segmentation

## v0.5 — Additional Exchangers
- Plate-and-frame
- Double-pipe
- Air-cooled exchanger
- Kettle / thermosiphon / condenser modes

## v0.6 — Optimisation
- Multi-objective optimisation
- Area / pressure-drop / cost / duty trade-offs
- Constraint handling
- Design-comparison telemetry

## v1.0 — Release Candidate
- Versioned project cases
- PDF/CSV/JSON technical pack
- SI / US-customary units
- Validation suite
- Documentation and references
- Deployment on Streamlit Community Cloud
